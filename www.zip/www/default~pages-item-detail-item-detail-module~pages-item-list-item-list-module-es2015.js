(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~pages-item-detail-item-detail-module~pages-item-list-item-list-module"],{

/***/ "./node_modules/@yellowspot/ng-truncate/fesm2015/yellowspot-ng-truncate.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@yellowspot/ng-truncate/fesm2015/yellowspot-ng-truncate.js ***!
  \*********************************************************************************/
/*! exports provided: TRUNCATE_PIPES, TruncateModule, ɵa, ɵb */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TRUNCATE_PIPES", function() { return TRUNCATE_PIPES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TruncateModule", function() { return TruncateModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵa", function() { return TruncateCharactersPipe; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵb", function() { return TruncateWordsPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class TruncateCharactersPipe {
    /**
     * @param {?} value
     * @param {?=} limit
     * @param {?=} trail
     * @return {?}
     */
    transform(value, limit = 40, trail = '…') {
        if (!value) {
            value = '';
        }
        if (limit < 0) {
            limit *= -1;
            return value.length > limit ? trail + value.substring(value.length - limit, value.length) : value;
        }
        else {
            return value.length > limit ? value.substring(0, limit) + trail : value;
        }
    }
}
TruncateCharactersPipe.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"], args: [{
                name: 'truncate'
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class TruncateWordsPipe {
    /**
     * @param {?} value
     * @param {?=} limit
     * @param {?=} trail
     * @return {?}
     */
    transform(value, limit = 40, trail = '…') {
        /** @type {?} */
        let result = value || '';
        if (value) {
            /** @type {?} */
            const words = value.split(/\s+/);
            if (words.length > Math.abs(limit)) {
                if (limit < 0) {
                    limit *= -1;
                    result = trail + words.slice(words.length - limit, words.length).join(' ');
                }
                else {
                    result = words.slice(0, limit).join(' ') + trail;
                }
            }
        }
        return result;
    }
}
TruncateWordsPipe.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"], args: [{
                name: 'words'
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const TRUNCATE_PIPES = [TruncateCharactersPipe, TruncateWordsPipe];
class TruncateModule {
}
TruncateModule.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"], args: [{
                declarations: [TRUNCATE_PIPES],
                exports: [TRUNCATE_PIPES]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */


//# sourceMappingURL=yellowspot-ng-truncate.js.map


/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/item-headline/item-headline.component.html":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/item-headline/item-headline.component.html ***!
  \********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-card button=\"true\" routerLink=\"/item-detail/{{ item.id }}\">\n  <ion-img [src]=\"item.enclosure\" *ngIf=\"item.enclosure else placeholder\"></ion-img>\n  <ion-card-header>\n    <ion-card-title>{{ item.title }}</ion-card-title>\n    <ion-card-subtitle>Javier - {{ item.createdAt.seconds*1000 | date: 'MMM d' }}</ion-card-subtitle>\n  </ion-card-header>\n  <ion-card-content>\n    {{ item.description | truncate:120 }}\n    <section>\n      <ion-chip *ngFor=\"let tag of item.tags; let i = index\" (click)=\"filterByTag($event, tag)\">\n        <ion-label>{{ tag.name }}</ion-label>\n      </ion-chip>\n    </section>\n  </ion-card-content>\n  <ion-row class=\"ion-justify-content-left\">\n    <ion-col size=\"8\" class=\"ion-text-left\">\n      <ion-button fill=\"clear\" size=\"small\" color=\"primary\" (click)=\"delete($event, item)\" *ngIf=\"item.id\">\n        <ion-icon name=\"trash\" slot=\"start\"></ion-icon>\n        Borrar\n      </ion-button>\n      <ion-button fill=\"clear\" size=\"small\" color=\"primary\" (click)=\"update($event, item)\" *ngIf=\"item.id\">\n          <ion-icon name=\"create\" slot=\"start\"></ion-icon>\n          Actualizar\n        </ion-button>\n    </ion-col>\n    <ion-col size=\"4\" class=\"ion-text-right\">\n      <!--         <ion-button fill=\"clear\" size=\"small\" color=\"primary\" (click)=\"like($event, item)\">\n            <ion-icon name=\"heart\" slot=\"start\"></ion-icon>\n        </ion-button>\n        <ion-button fill=\"clear\" size=\"small\" color=\"primary\" (click)=\"favorite($event, item)\">\n          <ion-icon name=\"star\" slot=\"start\"></ion-icon>\n        </ion-button>\n        <ion-button fill=\"clear\" size=\"small\" color=\"primary\" (click)=\"share($event, item)\">\n          <ion-icon name=\"share\" slot=\"start\"></ion-icon>\n        </ion-button> -->\n        <ion-button fill=\"clear\" size=\"small\" color=\"primary\" (click)=\"presentActionSheet($event, item)\">\n          <ion-icon name=\"more\" slot=\"start\"></ion-icon>\n        </ion-button>\n    </ion-col>\n  </ion-row>\n</ion-card>\n\n<ng-template #placeholder>\n  <ion-img src=\"https://ionicframework.com/docs/demos/api/card/madison.jpg\"></ion-img>\n</ng-template>\n");

/***/ }),

/***/ "./src/app/shared/components/item-headline/item-headline.component.scss":
/*!******************************************************************************!*\
  !*** ./src/app/shared/components/item-headline/item-headline.component.scss ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2l0ZW0taGVhZGxpbmUvaXRlbS1oZWFkbGluZS5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/shared/components/item-headline/item-headline.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/shared/components/item-headline/item-headline.component.ts ***!
  \****************************************************************************/
/*! exports provided: ItemHeadlineComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemHeadlineComponent", function() { return ItemHeadlineComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _item_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../item.model */ "./src/app/shared/item.model.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");




let ItemHeadlineComponent = class ItemHeadlineComponent {
    constructor(actionSheetController) {
        this.actionSheetController = actionSheetController;
        this.action = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.filter = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    presentActionSheet(event, item) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            event.preventDefault();
            event.stopPropagation();
            const actionSheet = yield this.actionSheetController.create({
                buttons: [{
                        text: 'Delete',
                        role: 'destructive',
                        icon: 'trash',
                        handler: () => {
                            this.delete(event, item);
                        }
                    }, {
                        text: 'Update',
                        icon: 'create',
                        handler: () => {
                            this.update(event, item);
                        }
                    }, {
                        text: 'Cancel',
                        icon: 'close',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        }
                    }]
            });
            yield actionSheet.present();
        });
    }
    delete(event, item) {
        event.preventDefault();
        event.stopPropagation();
        this.action.emit({
            functionName: 'deleteItem',
            functionParam: { item }
        });
    }
    update(event, item) {
        event.preventDefault();
        event.stopPropagation();
        this.action.emit({
            functionName: 'updateItem',
            functionParam: { item }
        });
    }
    like(event, item) {
        event.preventDefault();
        event.stopPropagation();
        console.log('Like clicked');
    }
    favorite(event, item) {
        event.preventDefault();
        event.stopPropagation();
        console.log('Favorite clicked');
    }
    share(event, item) {
        event.preventDefault();
        event.stopPropagation();
        console.log('Share clicked');
    }
    filterByTag(event, tag) {
        event.preventDefault();
        event.stopPropagation();
        this.filter.emit(tag);
    }
};
ItemHeadlineComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _item_model__WEBPACK_IMPORTED_MODULE_2__["Item"])
], ItemHeadlineComponent.prototype, "item", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], ItemHeadlineComponent.prototype, "action", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
], ItemHeadlineComponent.prototype, "filter", void 0);
ItemHeadlineComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectionStrategy"].OnPush,
        selector: 'app-item-headline',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./item-headline.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/item-headline/item-headline.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./item-headline.component.scss */ "./src/app/shared/components/item-headline/item-headline.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]])
], ItemHeadlineComponent);



/***/ }),

/***/ "./src/app/shared/item.model.ts":
/*!**************************************!*\
  !*** ./src/app/shared/item.model.ts ***!
  \**************************************/
/*! exports provided: ItemField, Item */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemField", function() { return ItemField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Item", function() { return Item; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var ItemField;
(function (ItemField) {
    ItemField["CREATED_AT"] = "createdAt";
    ItemField["PUBLISHED_AT"] = "publishedAt";
    ItemField["TAGS"] = "tags";
})(ItemField || (ItemField = {}));
class Item {
}


/***/ }),

/***/ "./src/app/shared/item.service.ts":
/*!****************************************!*\
  !*** ./src/app/shared/item.service.ts ***!
  \****************************************/
/*! exports provided: ItemService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemService", function() { return ItemService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ "./node_modules/@angular/fire/firestore/es2015/index.js");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! firebase/app */ "./node_modules/firebase/app/dist/index.cjs.js");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(firebase_app__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! firebase/firestore */ "./node_modules/firebase/firestore/dist/index.esm.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _item_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./item.model */ "./src/app/shared/item.model.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");



/**
 * Required import to use firebase.firestore.FieldValue
 * https://stackoverflow.com/a/52220012/4982169
 */





let ItemService = class ItemService {
    constructor(afs) {
        this.afs = afs;
        this.collectionPath = 'items';
        this.tagFilter$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["BehaviorSubject"](null);
        this.itemsCollection = afs.collection(this.collectionPath, ref => ref.orderBy(_item_model__WEBPACK_IMPORTED_MODULE_6__["ItemField"].PUBLISHED_AT, 'desc'));
    }
    get items$() {
        return this.tagFilter$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(tag => {
            return this.afs.collection(this.collectionPath, ref => {
                let query = ref;
                if (tag) {
                    query = query.where(_item_model__WEBPACK_IMPORTED_MODULE_6__["ItemField"].TAGS, 'array-contains', tag);
                }
                query = query.orderBy(_item_model__WEBPACK_IMPORTED_MODULE_6__["ItemField"].PUBLISHED_AT, 'desc');
                return query;
            }).valueChanges({ idField: 'id' });
        }));
    }
    /**
     * Inspired by https://angularfirebase.com/lessons/firestore-advanced-usage-angularfire/#3-CRUD-Operations-with-Server-Timestamps
     */
    get timestamp() {
        return firebase_app__WEBPACK_IMPORTED_MODULE_3__["firestore"].FieldValue.serverTimestamp();
    }
    push(item) {
        const timestamp = this.timestamp;
        return this.itemsCollection.add(Object.assign({}, item, { createdAt: timestamp, modifiedAt: timestamp, publishedAt: timestamp }));
    }
    getById(id) {
        // this.itemDoc = this.afs.doc<Item>('items/' + id);
        return this.itemsCollection.doc(id).valueChanges();
    }
    filterByTag(tag) {
        console.log('filterByTag: ', tag);
        this.tagFilter$.next(tag);
    }
    resetFilters() {
        this.tagFilter$.next(null);
    }
    remove(id) {
        return this.itemsCollection.doc(id).delete();
    }
    /**
     * AngularFirestore provides methods for setting, updating
     * - set(data: T) - Destructively updates a document's data.
     * - update(data: T) - Non-destructively updates a document's data.
     */
    set(id, data) {
        data.modifiedAt = this.timestamp;
        return this.itemsCollection.doc(id).set(data);
    }
    update(id, data) {
        data.modifiedAt = this.timestamp;
        return this.itemsCollection.doc(id).update(data);
    }
};
ItemService.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"] }
];
ItemService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"]])
], ItemService);



/***/ }),

/***/ "./src/app/shared/shared.module.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/*! exports provided: SharedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedModule", function() { return SharedModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _components_item_headline_item_headline_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/item-headline/item-headline.component */ "./src/app/shared/components/item-headline/item-headline.component.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _yellowspot_ng_truncate__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @yellowspot/ng-truncate */ "./node_modules/@yellowspot/ng-truncate/fesm2015/yellowspot-ng-truncate.js");







let SharedModule = class SharedModule {
};
SharedModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _components_item_headline_item_headline_component__WEBPACK_IMPORTED_MODULE_3__["ItemHeadlineComponent"],
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"],
            /**
             * A better solution should be to truncate text to the nearest whole word
             * http://codebuckets.com/2018/01/23/angular-pipe-to-truncate-text-to-the-nearest-whole-word/
             * OR https://stackoverflow.com/a/50651908/4982169
             */
            _yellowspot_ng_truncate__WEBPACK_IMPORTED_MODULE_6__["TruncateModule"],
        ],
        exports: [
            _components_item_headline_item_headline_component__WEBPACK_IMPORTED_MODULE_3__["ItemHeadlineComponent"],
        ]
    })
], SharedModule);



/***/ })

}]);
//# sourceMappingURL=default~pages-item-detail-item-detail-module~pages-item-list-item-list-module-es2015.js.map