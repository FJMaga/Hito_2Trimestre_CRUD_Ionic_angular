function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~pages-item-detail-item-detail-module~pages-item-list-item-list-module"], {
  /***/
  "./node_modules/@yellowspot/ng-truncate/fesm2015/yellowspot-ng-truncate.js":
  /*!*********************************************************************************!*\
    !*** ./node_modules/@yellowspot/ng-truncate/fesm2015/yellowspot-ng-truncate.js ***!
    \*********************************************************************************/

  /*! exports provided: TRUNCATE_PIPES, TruncateModule, ɵa, ɵb */

  /***/
  function node_modulesYellowspotNgTruncateFesm2015YellowspotNgTruncateJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TRUNCATE_PIPES", function () {
      return TRUNCATE_PIPES;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TruncateModule", function () {
      return TruncateModule;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ɵa", function () {
      return TruncateCharactersPipe;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ɵb", function () {
      return TruncateWordsPipe;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */


    var TruncateCharactersPipe =
    /*#__PURE__*/
    function () {
      function TruncateCharactersPipe() {
        _classCallCheck(this, TruncateCharactersPipe);
      }

      _createClass(TruncateCharactersPipe, [{
        key: "transform",

        /**
         * @param {?} value
         * @param {?=} limit
         * @param {?=} trail
         * @return {?}
         */
        value: function transform(value) {
          var limit = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 40;
          var trail = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '…';

          if (!value) {
            value = '';
          }

          if (limit < 0) {
            limit *= -1;
            return value.length > limit ? trail + value.substring(value.length - limit, value.length) : value;
          } else {
            return value.length > limit ? value.substring(0, limit) + trail : value;
          }
        }
      }]);

      return TruncateCharactersPipe;
    }();

    TruncateCharactersPipe.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"],
      args: [{
        name: 'truncate'
      }]
    }];
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    var TruncateWordsPipe =
    /*#__PURE__*/
    function () {
      function TruncateWordsPipe() {
        _classCallCheck(this, TruncateWordsPipe);
      }

      _createClass(TruncateWordsPipe, [{
        key: "transform",

        /**
         * @param {?} value
         * @param {?=} limit
         * @param {?=} trail
         * @return {?}
         */
        value: function transform(value) {
          var limit = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 40;
          var trail = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '…';

          /** @type {?} */
          var result = value || '';

          if (value) {
            /** @type {?} */
            var words = value.split(/\s+/);

            if (words.length > Math.abs(limit)) {
              if (limit < 0) {
                limit *= -1;
                result = trail + words.slice(words.length - limit, words.length).join(' ');
              } else {
                result = words.slice(0, limit).join(' ') + trail;
              }
            }
          }

          return result;
        }
      }]);

      return TruncateWordsPipe;
    }();

    TruncateWordsPipe.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"],
      args: [{
        name: 'words'
      }]
    }];
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /** @type {?} */

    var TRUNCATE_PIPES = [TruncateCharactersPipe, TruncateWordsPipe];

    var TruncateModule = function TruncateModule() {
      _classCallCheck(this, TruncateModule);
    };

    TruncateModule.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
      args: [{
        declarations: [TRUNCATE_PIPES],
        exports: [TRUNCATE_PIPES]
      }]
    }];
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    //# sourceMappingURL=yellowspot-ng-truncate.js.map

    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/item-headline/item-headline.component.html":
  /*!********************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/item-headline/item-headline.component.html ***!
    \********************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSharedComponentsItemHeadlineItemHeadlineComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-card button=\"true\" routerLink=\"/item-detail/{{ item.id }}\">\n  <ion-img [src]=\"item.enclosure\" *ngIf=\"item.enclosure else placeholder\"></ion-img>\n  <ion-card-header>\n    <ion-card-title>{{ item.title }}</ion-card-title>\n    <ion-card-subtitle>Javier - {{ item.createdAt.seconds*1000 | date: 'MMM d' }}</ion-card-subtitle>\n  </ion-card-header>\n  <ion-card-content>\n    {{ item.description | truncate:120 }}\n    <section>\n      <ion-chip *ngFor=\"let tag of item.tags; let i = index\" (click)=\"filterByTag($event, tag)\">\n        <ion-label>{{ tag.name }}</ion-label>\n      </ion-chip>\n    </section>\n  </ion-card-content>\n  <ion-row class=\"ion-justify-content-left\">\n    <ion-col size=\"8\" class=\"ion-text-left\">\n      <ion-button fill=\"clear\" size=\"small\" color=\"primary\" (click)=\"delete($event, item)\" *ngIf=\"item.id\">\n        <ion-icon name=\"trash\" slot=\"start\"></ion-icon>\n        Borrar\n      </ion-button>\n      <ion-button fill=\"clear\" size=\"small\" color=\"primary\" (click)=\"update($event, item)\" *ngIf=\"item.id\">\n          <ion-icon name=\"create\" slot=\"start\"></ion-icon>\n          Actualizar\n        </ion-button>\n    </ion-col>\n    <ion-col size=\"4\" class=\"ion-text-right\">\n      <!--         <ion-button fill=\"clear\" size=\"small\" color=\"primary\" (click)=\"like($event, item)\">\n            <ion-icon name=\"heart\" slot=\"start\"></ion-icon>\n        </ion-button>\n        <ion-button fill=\"clear\" size=\"small\" color=\"primary\" (click)=\"favorite($event, item)\">\n          <ion-icon name=\"star\" slot=\"start\"></ion-icon>\n        </ion-button>\n        <ion-button fill=\"clear\" size=\"small\" color=\"primary\" (click)=\"share($event, item)\">\n          <ion-icon name=\"share\" slot=\"start\"></ion-icon>\n        </ion-button> -->\n        <ion-button fill=\"clear\" size=\"small\" color=\"primary\" (click)=\"presentActionSheet($event, item)\">\n          <ion-icon name=\"more\" slot=\"start\"></ion-icon>\n        </ion-button>\n    </ion-col>\n  </ion-row>\n</ion-card>\n\n<ng-template #placeholder>\n  <ion-img src=\"https://ionicframework.com/docs/demos/api/card/madison.jpg\"></ion-img>\n</ng-template>\n";
    /***/
  },

  /***/
  "./src/app/shared/components/item-headline/item-headline.component.scss":
  /*!******************************************************************************!*\
    !*** ./src/app/shared/components/item-headline/item-headline.component.scss ***!
    \******************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSharedComponentsItemHeadlineItemHeadlineComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2l0ZW0taGVhZGxpbmUvaXRlbS1oZWFkbGluZS5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/shared/components/item-headline/item-headline.component.ts":
  /*!****************************************************************************!*\
    !*** ./src/app/shared/components/item-headline/item-headline.component.ts ***!
    \****************************************************************************/

  /*! exports provided: ItemHeadlineComponent */

  /***/
  function srcAppSharedComponentsItemHeadlineItemHeadlineComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemHeadlineComponent", function () {
      return ItemHeadlineComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _item_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../../item.model */
    "./src/app/shared/item.model.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/dist/fesm5.js");

    var ItemHeadlineComponent =
    /*#__PURE__*/
    function () {
      function ItemHeadlineComponent(actionSheetController) {
        _classCallCheck(this, ItemHeadlineComponent);

        this.actionSheetController = actionSheetController;
        this.action = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.filter = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
      }

      _createClass(ItemHeadlineComponent, [{
        key: "presentActionSheet",
        value: function presentActionSheet(event, item) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var actionSheet;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    event.preventDefault();
                    event.stopPropagation();
                    _context.next = 4;
                    return this.actionSheetController.create({
                      buttons: [{
                        text: 'Delete',
                        role: 'destructive',
                        icon: 'trash',
                        handler: function handler() {
                          _this.delete(event, item);
                        }
                      }, {
                        text: 'Update',
                        icon: 'create',
                        handler: function handler() {
                          _this.update(event, item);
                        }
                      }, {
                        text: 'Cancel',
                        icon: 'close',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Cancel clicked');
                        }
                      }]
                    });

                  case 4:
                    actionSheet = _context.sent;
                    _context.next = 7;
                    return actionSheet.present();

                  case 7:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "delete",
        value: function _delete(event, item) {
          event.preventDefault();
          event.stopPropagation();
          this.action.emit({
            functionName: 'deleteItem',
            functionParam: {
              item: item
            }
          });
        }
      }, {
        key: "update",
        value: function update(event, item) {
          event.preventDefault();
          event.stopPropagation();
          this.action.emit({
            functionName: 'updateItem',
            functionParam: {
              item: item
            }
          });
        }
      }, {
        key: "like",
        value: function like(event, item) {
          event.preventDefault();
          event.stopPropagation();
          console.log('Like clicked');
        }
      }, {
        key: "favorite",
        value: function favorite(event, item) {
          event.preventDefault();
          event.stopPropagation();
          console.log('Favorite clicked');
        }
      }, {
        key: "share",
        value: function share(event, item) {
          event.preventDefault();
          event.stopPropagation();
          console.log('Share clicked');
        }
      }, {
        key: "filterByTag",
        value: function filterByTag(event, tag) {
          event.preventDefault();
          event.stopPropagation();
          this.filter.emit(tag);
        }
      }]);

      return ItemHeadlineComponent;
    }();

    ItemHeadlineComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _item_model__WEBPACK_IMPORTED_MODULE_2__["Item"])], ItemHeadlineComponent.prototype, "item", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])], ItemHeadlineComponent.prototype, "action", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])], ItemHeadlineComponent.prototype, "filter", void 0);
    ItemHeadlineComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectionStrategy"].OnPush,
      selector: 'app-item-headline',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./item-headline.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/item-headline/item-headline.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./item-headline.component.scss */
      "./src/app/shared/components/item-headline/item-headline.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]])], ItemHeadlineComponent);
    /***/
  },

  /***/
  "./src/app/shared/item.model.ts":
  /*!**************************************!*\
    !*** ./src/app/shared/item.model.ts ***!
    \**************************************/

  /*! exports provided: ItemField, Item */

  /***/
  function srcAppSharedItemModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemField", function () {
      return ItemField;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Item", function () {
      return Item;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var ItemField;

    (function (ItemField) {
      ItemField["CREATED_AT"] = "createdAt";
      ItemField["PUBLISHED_AT"] = "publishedAt";
      ItemField["TAGS"] = "tags";
    })(ItemField || (ItemField = {}));

    var Item = function Item() {
      _classCallCheck(this, Item);
    };
    /***/

  },

  /***/
  "./src/app/shared/item.service.ts":
  /*!****************************************!*\
    !*** ./src/app/shared/item.service.ts ***!
    \****************************************/

  /*! exports provided: ItemService */

  /***/
  function srcAppSharedItemServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemService", function () {
      return ItemService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/fire/firestore */
    "./node_modules/@angular/fire/firestore/es2015/index.js");
    /* harmony import */


    var firebase_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! firebase/app */
    "./node_modules/firebase/app/dist/index.cjs.js");
    /* harmony import */


    var firebase_app__WEBPACK_IMPORTED_MODULE_3___default =
    /*#__PURE__*/
    __webpack_require__.n(firebase_app__WEBPACK_IMPORTED_MODULE_3__);
    /* harmony import */


    var firebase_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! firebase/firestore */
    "./node_modules/firebase/firestore/dist/index.esm.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _item_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./item.model */
    "./src/app/shared/item.model.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /**
     * Required import to use firebase.firestore.FieldValue
     * https://stackoverflow.com/a/52220012/4982169
     */


    var ItemService =
    /*#__PURE__*/
    function () {
      function ItemService(afs) {
        _classCallCheck(this, ItemService);

        this.afs = afs;
        this.collectionPath = 'items';
        this.tagFilter$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["BehaviorSubject"](null);
        this.itemsCollection = afs.collection(this.collectionPath, function (ref) {
          return ref.orderBy(_item_model__WEBPACK_IMPORTED_MODULE_6__["ItemField"].PUBLISHED_AT, 'desc');
        });
      }

      _createClass(ItemService, [{
        key: "push",
        value: function push(item) {
          var timestamp = this.timestamp;
          return this.itemsCollection.add(Object.assign({}, item, {
            createdAt: timestamp,
            modifiedAt: timestamp,
            publishedAt: timestamp
          }));
        }
      }, {
        key: "getById",
        value: function getById(id) {
          // this.itemDoc = this.afs.doc<Item>('items/' + id);
          return this.itemsCollection.doc(id).valueChanges();
        }
      }, {
        key: "filterByTag",
        value: function filterByTag(tag) {
          console.log('filterByTag: ', tag);
          this.tagFilter$.next(tag);
        }
      }, {
        key: "resetFilters",
        value: function resetFilters() {
          this.tagFilter$.next(null);
        }
      }, {
        key: "remove",
        value: function remove(id) {
          return this.itemsCollection.doc(id).delete();
        }
        /**
         * AngularFirestore provides methods for setting, updating
         * - set(data: T) - Destructively updates a document's data.
         * - update(data: T) - Non-destructively updates a document's data.
         */

      }, {
        key: "set",
        value: function set(id, data) {
          data.modifiedAt = this.timestamp;
          return this.itemsCollection.doc(id).set(data);
        }
      }, {
        key: "update",
        value: function update(id, data) {
          data.modifiedAt = this.timestamp;
          return this.itemsCollection.doc(id).update(data);
        }
      }, {
        key: "items$",
        get: function get() {
          var _this2 = this;

          return this.tagFilter$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["switchMap"])(function (tag) {
            return _this2.afs.collection(_this2.collectionPath, function (ref) {
              var query = ref;

              if (tag) {
                query = query.where(_item_model__WEBPACK_IMPORTED_MODULE_6__["ItemField"].TAGS, 'array-contains', tag);
              }

              query = query.orderBy(_item_model__WEBPACK_IMPORTED_MODULE_6__["ItemField"].PUBLISHED_AT, 'desc');
              return query;
            }).valueChanges({
              idField: 'id'
            });
          }));
        }
        /**
         * Inspired by https://angularfirebase.com/lessons/firestore-advanced-usage-angularfire/#3-CRUD-Operations-with-Server-Timestamps
         */

      }, {
        key: "timestamp",
        get: function get() {
          return firebase_app__WEBPACK_IMPORTED_MODULE_3__["firestore"].FieldValue.serverTimestamp();
        }
      }]);

      return ItemService;
    }();

    ItemService.ctorParameters = function () {
      return [{
        type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"]
      }];
    };

    ItemService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"]])], ItemService);
    /***/
  },

  /***/
  "./src/app/shared/shared.module.ts":
  /*!*****************************************!*\
    !*** ./src/app/shared/shared.module.ts ***!
    \*****************************************/

  /*! exports provided: SharedModule */

  /***/
  function srcAppSharedSharedModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SharedModule", function () {
      return SharedModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _components_item_headline_item_headline_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./components/item-headline/item-headline.component */
    "./src/app/shared/components/item-headline/item-headline.component.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/dist/fesm5.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _yellowspot_ng_truncate__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @yellowspot/ng-truncate */
    "./node_modules/@yellowspot/ng-truncate/fesm2015/yellowspot-ng-truncate.js");

    var SharedModule = function SharedModule() {
      _classCallCheck(this, SharedModule);
    };

    SharedModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      declarations: [_components_item_headline_item_headline_component__WEBPACK_IMPORTED_MODULE_3__["ItemHeadlineComponent"]],
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"],
      /**
       * A better solution should be to truncate text to the nearest whole word
       * http://codebuckets.com/2018/01/23/angular-pipe-to-truncate-text-to-the-nearest-whole-word/
       * OR https://stackoverflow.com/a/50651908/4982169
       */
      _yellowspot_ng_truncate__WEBPACK_IMPORTED_MODULE_6__["TruncateModule"]],
      exports: [_components_item_headline_item_headline_component__WEBPACK_IMPORTED_MODULE_3__["ItemHeadlineComponent"]]
    })], SharedModule);
    /***/
  }
}]);
//# sourceMappingURL=default~pages-item-detail-item-detail-module~pages-item-list-item-list-module-es5.js.map