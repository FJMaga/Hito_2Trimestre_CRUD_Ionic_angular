function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-item-list-item-list-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/item-list/item-list.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/item-list/item-list.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesItemListItemListPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Listado</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid fixed>\n    <ion-row>\n      <ion-toolbar *ngIf=\"currentTag let tag\">\n        <ion-chip (click)=\"resetFilters()\">\n          <ion-label>{{ tag.name }}</ion-label>\n          <ion-icon name=\"close-circle\"></ion-icon>\n        </ion-chip>\n      </ion-toolbar>\n    </ion-row>\n    <ion-row *ngIf=\"items$ | async; let items;else loading\">\n      <ion-col size=\"12\" size-md=\"6\" *ngFor=\"let item of items$ | async\">\n        <app-item-headline [item]=\"item\" (action)=\"handleItemAction($event)\" (filter)=\"filterByTag($event)\">\n        </app-item-headline>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <div *ngIf=\"(items$ | async)?.length == 0\" class=\"empty-illustration\">\n    <img src=\"/assets/undraw_empty.svg\"/>\n  </div>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button>\n      <ion-icon name=\"add\" routerLink=\"/item-add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n</ion-content>\n\n<!-- Skeleton screen -->\n<ng-template #loading>\n  <ion-row>\n    <ion-col size=\"12\" size-md=\"6\" *ngFor=\"let number of [0,1,2,3,4]\">\n      <ion-list>\n        <ion-list-header>\n          <ion-skeleton-text animated style=\"width: 20%\"></ion-skeleton-text>\n        </ion-list-header>\n        <ion-item>\n          <ion-avatar slot=\"start\">\n            <ion-skeleton-text animated></ion-skeleton-text>\n          </ion-avatar>\n          <ion-label>\n            <h3>\n              <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n            </h3>\n            <p>\n              <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n            </p>\n            <p>\n              <ion-skeleton-text animated style=\"width: 60%\"></ion-skeleton-text>\n            </p>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n    </ion-col>\n  </ion-row>\n</ng-template>";
    /***/
  },

  /***/
  "./src/app/pages/item-list/item-list.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/item-list/item-list.module.ts ***!
    \*****************************************************/

  /*! exports provided: ItemListPageModule */

  /***/
  function srcAppPagesItemListItemListModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemListPageModule", function () {
      return ItemListPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/dist/fesm5.js");
    /* harmony import */


    var _item_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./item-list.page */
    "./src/app/pages/item-list/item-list.page.ts");
    /* harmony import */


    var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/shared/shared.module */
    "./src/app/shared/shared.module.ts");

    var routes = [{
      path: '',
      component: _item_list_page__WEBPACK_IMPORTED_MODULE_6__["ItemListPage"]
    }];

    var ItemListPageModule = function ItemListPageModule() {
      _classCallCheck(this, ItemListPageModule);
    };

    ItemListPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes), src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"]],
      declarations: [_item_list_page__WEBPACK_IMPORTED_MODULE_6__["ItemListPage"]]
    })], ItemListPageModule);
    /***/
  },

  /***/
  "./src/app/pages/item-list/item-list.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/pages/item-list/item-list.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesItemListItemListPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".empty-illustration {\n  padding: 50px;\n  min-height: 200px;\n  text-align: center;\n}\n\n.empty-illustration img {\n  max-width: 250px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2phdmkvRGVzY2FyZ2FzL2NydWQtYW5ndWxhci1maXJlc3RvcmUtaW9uaWMvc3JjL2FwcC9wYWdlcy9pdGVtLWxpc3QvaXRlbS1saXN0LnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvaXRlbS1saXN0L2l0ZW0tbGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQ0NGOztBREVBO0VBQ0UsZ0JBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2l0ZW0tbGlzdC9pdGVtLWxpc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmVtcHR5LWlsbHVzdHJhdGlvbiB7XG4gIHBhZGRpbmc6IDUwcHg7XG4gIG1pbi1oZWlnaHQ6IDIwMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5lbXB0eS1pbGx1c3RyYXRpb24gaW1nIHtcbiAgbWF4LXdpZHRoOiAyNTBweDtcbn0iLCIuZW1wdHktaWxsdXN0cmF0aW9uIHtcbiAgcGFkZGluZzogNTBweDtcbiAgbWluLWhlaWdodDogMjAwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmVtcHR5LWlsbHVzdHJhdGlvbiBpbWcge1xuICBtYXgtd2lkdGg6IDI1MHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/item-list/item-list.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/item-list/item-list.page.ts ***!
    \***************************************************/

  /*! exports provided: ItemListPage */

  /***/
  function srcAppPagesItemListItemListPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemListPage", function () {
      return ItemListPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _shared_item_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../shared/item.service */
    "./src/app/shared/item.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/dist/fesm5.js");

    var ItemListPage =
    /*#__PURE__*/
    function () {
      function ItemListPage(itemsService, router, alertController) {
        _classCallCheck(this, ItemListPage);

        this.itemsService = itemsService;
        this.router = router;
        this.alertController = alertController;
      }

      _createClass(ItemListPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.items$ = this.itemsService.items$;
        }
      }, {
        key: "handleItemAction",
        value: function handleItemAction(event) {
          var functionName = event.functionName;

          if (this[functionName]) {
            // method exists on the component
            var param = event.functionParam;
            this[functionName](param.item); // call it
          }
        }
      }, {
        key: "deleteItem",
        value: function deleteItem(item) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.alertController.create({
                      message: 'Are you sure you want to delete this?',
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler() {
                          console.log('Confirm Cancel: ', item.title);
                        }
                      }, {
                        text: 'Yes',
                        handler: function handler() {
                          _this.itemsService.remove(item.id);
                        }
                      }]
                    });

                  case 2:
                    alert = _context.sent;
                    _context.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "updateItem",
        value: function updateItem(item) {
          this.router.navigate(["/item-edit/".concat(item.id)]);
        }
      }, {
        key: "filterByTag",
        value: function filterByTag(tag) {
          console.log('Filter by tag: ', tag);
          this.currentTag = tag;
          this.itemsService.filterByTag(tag);
        }
      }, {
        key: "resetFilters",
        value: function resetFilters() {
          this.currentTag = null;
          this.itemsService.resetFilters();
        }
      }]);

      return ItemListPage;
    }();

    ItemListPage.ctorParameters = function () {
      return [{
        type: _shared_item_service__WEBPACK_IMPORTED_MODULE_3__["ItemService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
      }];
    };

    ItemListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-item-list',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./item-list.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/item-list/item-list.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./item-list.page.scss */
      "./src/app/pages/item-list/item-list.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_item_service__WEBPACK_IMPORTED_MODULE_3__["ItemService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])], ItemListPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-item-list-item-list-module-es5.js.map